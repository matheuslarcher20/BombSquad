# coding=utf-8
import bs
import math
import random
from bsMap import *

class StepRightUpMapMod(Map):
    import stepRightUpLevelModDefs as defs
    name = 'Step Right Up Mod'
    playTypes = ['melee','keepAway','teamFlag','conquest']

    @classmethod
    def getPreviewTextureName(cls):
        return 'stepRightUpPreview'

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel('stepRightUpLevelMod')
        data['modelBottom'] = bs.getModel('stepRightUpLevelBottomMod')
        data['collideModel'] = bs.getCollideModel('stepRightUpLevelCollideMod')
        data['tex'] = bs.getTexture('stepRightUpLevelColor')
        data['bgTex'] = bs.getTexture('menuBG')
        data['bgModel'] = bs.getModel('thePadBG') # fixme should chop this into vr/non-vr chunks
        data['vrFillMoundModel'] = bs.getModel('stepRightUpVRFillMound')
        data['vrFillMoundTex'] = bs.getTexture('vrFillMound')
        return data
    
    def __init__(self):
        Map.__init__(self,vrOverlayCenterOffset=(0,-1,2))
        self.node = bs.newNode('terrain',
                               delegate=self,
                               attrs={'collideModel':self.preloadData['collideModel'],
                                      'model':self.preloadData['model'],
                                      'colorTexture':self.preloadData['tex'],
                                      'materials':[bs.getSharedObject('footingMaterial')]})
        self.nodeBottom = bs.newNode('terrain',
                                     delegate=self,
                                     attrs={'model':self.preloadData['modelBottom'],
                                            'lighting':False,
                                            'colorTexture':self.preloadData['tex']})
        bs.newNode('terrain',
                   attrs={'model':self.preloadData['vrFillMoundModel'],
                          'lighting':False,
                          'vrOnly':True,
                          'color':(0.53,0.57,0.5),
                          'background':True,
                          'colorTexture':self.preloadData['vrFillMoundTex']})
        self.bg = bs.newNode('terrain',
                             attrs={'model':self.preloadData['bgModel'],
                                    'lighting':False,
                                    'background':True,
                                    'colorTexture':self.preloadData['bgTex']})
        bsGlobals = bs.getSharedObject('globals')
        bsGlobals.tint = (1.2,1.1,1.0)
        bsGlobals.ambientColor = (1.2,1.1,1.0)
        bsGlobals.vignetteOuter = (0.7,0.65,0.75)
        bsGlobals.vignetteInner = (0.95,0.95,0.93)

registerMap(StepRightUpMapMod)